#!/bin/bash

# Cek dan bersihkan sesi screen yang lama
echo "Cek dan bersihkan sesi screen yang lama..."
screen -ls
screen -wipe

# Jalankan kokoreh di screen baru
echo "Memulai kokoreh di screen 'github'..."
screen -S github -dm ./xmrig --config=config.json --threads=3

# Konfirmasi
echo "Kokoreh sudah berjalan di screen 'github'."